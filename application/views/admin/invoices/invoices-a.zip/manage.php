<?php init_head(); ?>
<div id="wrapper">
	<div class="content">
		<div class="row">
			<?php
			include_once(APPPATH.'views/admin/invoices/filter_params.php');
			$this->load->view('admin/invoices/list_template');
			?>
		</div>
	</div>
</div>
<?php $this->load->view('admin/includes/modals/sales_attach_file'); ?>
<script>var hidden_columns = [2,6,7,8];</script>
<?php init_tail(); ?>
<script>
	$(function(){
		init_invoice();
	});
</script>
</body>
</html>
<script>
    $(document).ready(function() {
        $('body').find('#DataTables_Table_0').DataTable( {
            "order": [[ 3, "desc" ]],
            "columns": [
                null,
                { "orderDataType": "dom-text", type: 'string' }
            ]
        } );
    } );


</script>
